package it.uniroma3.siw.taskmanager.controller;



import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import it.uniroma3.siw.taskmanager.model.User;
import it.uniroma3.siw.taskmanager.service.CredentialsService;
import it.uniroma3.siw.taskmanager.service.ProjectService;
import it.uniroma3.siw.taskmanager.service.UserService;
import it.uniroma3.siw.taskmanager.session.SessionData;
import it.uniroma3.siw.taskmanager.validator.ProjectValidator;
import it.uniroma3.siw.taskmanager.model.Credentials;
import it.uniroma3.siw.taskmanager.model.Project;

@Controller
public class ProjectController {

	@Autowired
	SessionData sessionData;
	
	@Autowired
	ProjectService projectService; 
	
	@Autowired
	UserService userService;
	
	@Autowired
	ProjectValidator projectValidator;
	
	@Autowired
	CredentialsService credentialsService;
	
	@RequestMapping(value = {"/projects"}, method = RequestMethod.GET)
	public String myOwendProjects(Model model) {
		User loggedUser = sessionData.getLoggedUser();
		List<Project>projectsList = projectService.retrieveProjectOwnedBy(loggedUser);
		model.addAttribute("loggedUser", loggedUser);
		model.addAttribute("projectsList", projectsList);
		return "myOwnedProjects";	
	}
	
	@RequestMapping(value = {"/projects/{projectId}"}, method = RequestMethod.GET)
	public String project(Model model, 
						@PathVariable Long projectId) {
		User loggedUser = sessionData.getLoggedUser();
		Project project = projectService.getProject(projectId);
		if (project == null)
			return "redirect:/projects";
		
		List<User> members = userService.getMembers(project);
		if(!project.getOwner().equals(loggedUser) && !members.contains(loggedUser))
			return "redirect:/projects";
		model.addAttribute("loggedUser", loggedUser);
		model.addAttribute("project", project);
		model.addAttribute("members", members);
		
		
		return "project";
	}
	
	@RequestMapping(value = {"/projects/add"}, method = RequestMethod.GET)
	public String createProjectForm(Model model) {
		User loggedUser = sessionData.getLoggedUser();
		model.addAttribute("loggedUser", loggedUser);
		model.addAttribute("projectForm", new Project());
		return "addProject";
	}
	
	@RequestMapping(value= {"/projects/add"}, method = RequestMethod.POST)
	public String createProject (@Valid @ModelAttribute("projectForm") Project project,
								BindingResult projectBindingResult, 
								Model model) {
		User loggedUser = sessionData.getLoggedUser();
		
		projectValidator.validate(project, projectBindingResult);
		if(!projectBindingResult.hasErrors()) {
			project.setOwner(loggedUser);
			this.projectService.saveProject(project);
			return "redirect:/projects/" + project.getId();
		}
		model.addAttribute("loggedUser", loggedUser);
		return "addProject";
	}
	
	
/*MODIFICA DEL PROGGETTO*/
	
	@RequestMapping(value= {"/projects/update"},method=RequestMethod.GET)
	public String modifyProjectDirection(Model model) {
		User loggedUser=sessionData.getLoggedUser();
		model.addAttribute("user",loggedUser);
		model.addAttribute("projectForm",new Project());
		return "updateProject";
	}



	@RequestMapping(value= {"/projects/update"},method=RequestMethod.POST)  //PROVARE A FARE VALIDATOR
	public String modifyProject(@Valid @ModelAttribute("projectForm") Project project,
			BindingResult projectBindingResult,Model model)
	{	
		User loggedUser=sessionData.getLoggedUser();
		this.projectValidator.validate(project,projectBindingResult);

		Long id=project.getId();
		Project currentProject = this.projectService.getProject(id);
		if(!projectBindingResult.hasErrors()) {
			if(currentProject!=null && currentProject.getOwner().equals(loggedUser)) {
				currentProject.setName(project.getName());
				currentProject.setDescription(project.getDescription());
				currentProject.setOwner(loggedUser);
				this.projectService.saveProject(currentProject);
				return "updateProjectSuccess";
			}
		}
		return "updateProject";
	}


/*CONDIVISIONE PROGGETTO CON UN ALTRO UTENTE*/
	@RequestMapping(value= {"/projects/share"},method=RequestMethod.GET)
	public String shareProject(Model model) {
		User loggedUser=sessionData.getLoggedUser();
		model.addAttribute("user",loggedUser);
		model.addAttribute("projectForm",new Project());
		model.addAttribute("credentialsForm",new Credentials());
		return "shareProject";
	}

	@RequestMapping(value= {"/projects/share"},method=RequestMethod.POST)  //PROVARE A FARE VALIDATOR
	public String modifyMyProject(
			@Valid @ModelAttribute("credentialsForm") Credentials credentials,
			@Valid @ModelAttribute("projectForm") Project project,
			BindingResult projectBindingResult,Model model) {	
		User loggedUser=sessionData.getLoggedUser();
		Long id=project.getId();
		if(this.projectService.getProject(id)!=null&&this.projectService.getProject(id).getOwner().equals(loggedUser)) {
			Project projects=this.projectService.getProject(project.getId());
			String Username=credentials.getUserName();
			if(this.credentialsService.getCredentials(Username)!=null) {
				projects=this.projectService.shareProjectWithUser(projects, this.credentialsService.getCredentials(credentials.getUserName()).getUser());
				projects.setOwner(loggedUser);
				this.projectService.saveProject(projects);
				return "shareProjectSuccess";
			}
		}
		return "shareProject";
	}


/*VISIONE DEI PROGGETTI CONDIVISI*/
	@RequestMapping(value= {"/projects/shared"}, method=RequestMethod.GET)
	public String listOfSharedProject(Model model) {
		User loggedUser=sessionData.getLoggedUser();
		List<Project> projectsList=this.projectService.findMembers(loggedUser);
		model.addAttribute("user", loggedUser);
		model.addAttribute("projectsList", projectsList);
		return "myVisibleProject";
		}

		@RequestMapping(value= {"/projects/shared/{projectId}"}, method=RequestMethod.GET)
		public String sharedProject(Model model, @PathVariable Long projectId) {
			User loggedUser=this.sessionData.getLoggedUser();
			Project project=this.projectService.getProject(projectId);
			if(project==null)  return "redirect:/projects";

			List<User> members=this.userService.getMembers(project);
			if(!project.getOwner().equals(loggedUser)&&!members.contains(loggedUser)) 
				return "redirect:/projects";

		
			model.addAttribute("loggedUser",loggedUser);
			model.addAttribute("project",project);
			model.addAttribute("members",members);

		
	
			return "viewProject";
		}
		
/*ELIMINARE UN PROGGETTO*/
		@RequestMapping(value= {"/projects/delete"},method=RequestMethod.GET)
		public String deleteProject(Model model) {
			User loggedUser=sessionData.getLoggedUser();
			model.addAttribute("user",loggedUser);
			model.addAttribute("projectForm",new Project());
			return "deleteProject";
		}


		@RequestMapping(value= {"/projects/delete"},method=RequestMethod.POST)
		public String deleteProjectSuccess(@Valid @ModelAttribute("projectForm") Project project,
											BindingResult projectBindingResult,Model model) {	
			User loggedUser=sessionData.getLoggedUser();
			Long id=project.getId();
			if(this.projectService.getProject(id)!=null&&this.projectService.getProject(id).getOwner().equals(loggedUser)) {
				Project projecto=this.projectService.getProject(project.getId());
				this.projectService.deleteProject(projecto);
				return "deleteProjectSuccess";
			}
			return "deleteProject";
		}
	
		
}
