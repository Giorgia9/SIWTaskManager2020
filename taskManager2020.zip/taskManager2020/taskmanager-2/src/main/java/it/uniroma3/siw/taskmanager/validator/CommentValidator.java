package it.uniroma3.siw.taskmanager.validator;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import it.uniroma3.siw.taskmanager.model.Comment;

@Component
public class CommentValidator implements Validator{

	@Override
	public boolean supports(Class<?> clazz) {
		return Comment.class.equals(clazz);
	}

	@Override
	public void validate(Object o, Errors errors) {
		final Integer MAX_COMMENT_LENGTH=1000;
		final Integer MIN_COMMENT_LENGTH=2;
		
		Comment comment = (Comment) o; 
		if(comment.getCommentText().length()< MIN_COMMENT_LENGTH||
		  comment.getCommentText().length() > MAX_COMMENT_LENGTH)
			errors.rejectValue("commentText", "size");

	}

}
