(function(){
 prettyPrint();
})();